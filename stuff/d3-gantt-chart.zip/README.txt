A Pen created at CodePen.io. You can find this one at https://codepen.io/jey/pen/jmClJ.

 Decided to procrastinate by making a d3 gantt chart, realized the absurdity about 80% of the way through. This is where I got.